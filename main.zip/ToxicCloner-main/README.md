# ToxicCloner V1.0

A Bangladeshi Facebook ID Cloning Tool

# Installation Commands :

apt update -y

apt upgrade -y

pkg install python git -y

git clone https://github.com/Toxic-Noob/ToxicCloner

cd ToxciCloner

pip install -r requirements.txt

python tcloner.py

# Single Installation Commands :
``` shell script
apt update -y && apt upgrade -y && pkg install python git -y && git clone https://github.com/Toxic-Noob/ToxicCloner && cd ToxicCloner && pip install -r requirements.txt && python tcloner.py
```

# Contact :

[*] For Any Need, Contact Via Mail:

ToxicNoob.Sl4d3.Official@gmail.com

<br><br>
# Visitors :


![Visitor Count](https://profile-counter.glitch.me/Toxic-Noob/count.svg)
